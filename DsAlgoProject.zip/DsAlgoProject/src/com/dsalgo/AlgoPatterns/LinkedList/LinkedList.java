package com.dsalgo.AlgoPatterns.LinkedList;

public class LinkedList {

}
